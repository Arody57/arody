$(document).ready(function(){
    $('#load').delay(2000).fadeOut("slow");
});
